# Copyright © 2020 Hashmap, Inc
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
import time
from contextlib import contextmanager
import yaml
from hdm.core.dao.db_dao import DBDAO
from hdm.core.utils.project_config import ProjectConfig
from google.cloud import bigquery
# from google.oauth2 import service_account
import os

class BigQuery(DBDAO):
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._bucket = None

    def _get_connection(self):

        with open(f"{ProjectConfig.hdm_home()}/{ProjectConfig.profile_path()}", 'r') as stream:
            conn_conf = yaml.safe_load(stream)[ProjectConfig.hdm_env()][self._connection]

        self._bucket = conn_conf['bucket_name']
        # credentials = service_account.Credentials.from_service_account_file(conn_conf['service_json'])
        # connection = bigquery.Client(credentials=credentials)
        
        service_account_key_path = conn_conf['service_json']
        project_id = conn_conf['dataset']
        
        # with open(yaml_file_path, 'r') as stream:
        #     config = yaml.safe_load(os.path.expandvars(stream.read()))
        #     service_account_key_path = config['bigquery']['client_service_json'].split('.json')[0] + '.json' # this is because path is appended with datetime. need to fix that
        #     project_id = config['bigquery']['dataset']

       
        #service_account_key_path = r"C:\NTTDATA\Deutche_bank\bigquery-eval-hd1341-f4215fb67922.json"
        #project_id = "bigquery-eval-hd1341"
        client = bigquery.Client.from_service_account_json(service_account_key_path, project=project_id)


        if not self._test_connection(client):
            raise ConnectionError('Unable to connect to BigQuery. Please check configuration key values in profile.yml or try again.')
        return client

    def _test_connection(self, connection) -> bool:
        result = False
        if connection:
            try:
                result = bool(connection.project)
            except Exception:
                return False

        return result

    # def _test_bucket_existence(self, connection) -> bool:
    #     """
    #     check if blob container exists

    #     Returns: True if bucket exists, False otherwise

    #     """
    #     if not connection:
    #         return False

    #     try:
    #         # Throws exception if container not available
    #         return bool(connection.get_bucket(self._bucket))

    #     except storage.core.exceptions.ResourceNotFoundError:
    #         self._create_bucket(connection)
    #         return True

    # def _create_bucket(self, connection):
    #     """
    #     creates a bucket

    #     Returns:

    #     """
    #     connection.create_bucket(self._bucket)

    def _validate_configuration(self) -> bool:
        with open(f"{ProjectConfig.hdm_home()}/{ProjectConfig.profile_path()}", 'r') as stream:
            conn_conf = yaml.safe_load(stream)[ProjectConfig.hdm_env()][self._connection_name]

        required_keys = ['service_json', 'bucket_name']
        is_valid = all([key in conn_conf.keys() for key in required_keys])
        return is_valid
