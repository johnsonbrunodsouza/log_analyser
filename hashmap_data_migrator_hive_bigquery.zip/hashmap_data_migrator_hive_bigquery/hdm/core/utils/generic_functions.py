from datetime import datetime


class GenericFunctions:

    @classmethod
    def folder_to_table(cls, name):
        returnvalue = ""
        if name.find('___') < 0:
            returnvalue = name.replace("__", ".")
        else:
            returnvalue = name.replace("___", ".")
        #return name.replace("___", ".")
        return returnvalue

    @classmethod
    def table_to_folder(cls, name):
        returnvalue = ""
        # the below is for Hive as data source. Hive don't have schemas
        if name.find(".") < 0:
            name = "DEFAULT." + name
        if name.find('__') < 0:
            returnvalue = name.replace(".", "__")
        else:
            returnvalue = name.replace(".", "___")
        #return name.replace(".", "__")
        return returnvalue

    @classmethod
    def string_to_datetime(cls, str_date):
        return datetime.strptime(str_date, '%Y-%m-%d %H:%M:%S.%f')

    @classmethod
    def datetime_to_string(cls, date_obj):
        return date_obj.strftime('%Y-%m-%d %H:%M:%S.%f')

    @classmethod
    def table_name_only(cls, table_name):
        return table_name[len(table_name.split('.')[0]) + 1:]

    @classmethod
    def table_name_with_quotes(cls, table_name):
        return f"\"{table_name.split('.')[0]}\".\"{table_name[len(table_name.split('.')[0]) + 1:]}\""
