# Copyright © 2020 Hashmap, Inc
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from sqlalchemy import false
from hdm.core.sink.rdbms_sink import RDBMSSink
import datetime
from hdm.core.utils.generic_functions import GenericFunctions
from jinjasql import JinjaSql
from hdm.core.query_templates.query_templates import QueryTemplates
from snowflake.connector import DictCursor

class SnowflakeCopySink(RDBMSSink):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        # Query content
        self._file_format = kwargs['env']['file_format']
        self._stage_name = GenericFunctions.table_to_folder(kwargs['stage_name'])  
        self._original_table_name = kwargs['stage_name']  
        self._query = ""
        self._encoding = ""
        self._merge_mode = ""
        self._keytablename = ""
        if 'cdc' in kwargs['table']:
            self._merge_mode = kwargs['table']['cdc']['mode']
            self._keytablename = kwargs['table']['cdc']['keytable']['tablename']

        self._primarykeys = kwargs['data_dict']['primarykeys']

        if 'encoding' in kwargs['table']:
            self._encoding = kwargs['table']['encoding']
                
        self._watermark_column = kwargs['table']['watermark']['column']
        self._source_for_copy = kwargs['source_for_copy']
        self._snowflake_database = kwargs['snowflake_database']


    def produce(self, **kwargs) -> None:
        return self._run(**kwargs)

    def _set_data(self, **kwargs):
        file_name = 'F'
        #table_name = GenericFunctions.folder_to_table(self._stage_name).split('.')[1]
        table_name = GenericFunctions.table_name_only(GenericFunctions.folder_to_table(self._stage_name)).upper()
        self._logger.info(f"Initiating import for {table_name} from {self._source_for_copy}")
        if self._merge_mode == None or (self._merge_mode.lower() == 'incremental' and not self._last_iteration) or self._merge_mode.lower() == 'full':
            with self._dao.connection as conn:                
                self._entity = f"{self._stage_name}"
                self._entity_filter = None            
                self._generate_query(file_name, table_name)

                cursor = conn.cursor()
                
                if not self._merge_mode == None:
                    if self._merge_mode.lower() == 'full' and self._first_iteration:
                        self._logger.info(f"Truncating table {table_name} as merger mode specified is: {self._merge_mode}")
                        truncatequery = self._generate_query_for_truncation(table_name)
                        cursor.execute(truncatequery)

                self._logger.info("Executing copy from @%s into %s", self._stage_name, table_name)                
                self._logger.info(f"Copy Query: {self._query}")
                cursor.execute(self._query)    

                get_record_counts = self._generate_query_for_record_count(table_name, self._source_for_copy)
                self._data_dict['snowflake_record_count'] = cursor.execute(get_record_counts).fetchone()[0]
        else:            
            with self._dao.connection as conn:                
                self._entity = f"{self._stage_name}"
                self._entity_filter = None
                cursor = conn.cursor()
                
                getddl = self._generate_query_for_table_creation_for_cdc(table_name)                
                cursor.execute(getddl)
                for rec in cursor:
                    getddl = rec[0]
                    break
                
                currenttimestamp = str(datetime.datetime.now()).replace(' ','').replace('-','').replace(':','').replace('.','')
                cdctable = getddl.split(' ')[4] + '_CDC_' + currenttimestamp
                getddl = getddl.replace(table_name, cdctable, 1)
                self._entity = f"{self._stage_name}.{cdctable}"
                self._logger.info(f"Creating table {cdctable}. Query: {getddl}")
                cursor.execute(getddl)

                self._generate_query(file_name, cdctable)
                self._logger.info("Executing copy from @%s into %s", self._stage_name, cdctable)
                self._logger.info(f"Copy Query: {self._query}")
                cursor.execute(self._query)

                get_record_counts = self._generate_query_for_record_count(cdctable, self._source_for_copy)
                self._data_dict['snowflake_record_count'] = cursor.execute(get_record_counts).fetchone()[0]

                self._logger.info(f"Merging data from {cdctable} into {table_name}")
                mergequeries = self._generate_query_for_merge(table_name, cdctable)
                for mergequery in mergequeries:
                    self._logger.info(f"Query: {mergequery}")
                    cursor.execute(mergequery)

                self._logger.info(f"Dropping table {cdctable}")
                cursor.execute(f"DROP TABLE IF EXISTS {cdctable}")

    def _fetch_last_watermark_value(self):     
        #table_name = GenericFunctions.folder_to_table(self._stage_name).split('.')[1] 
        table_name = GenericFunctions.table_name_only(GenericFunctions.folder_to_table(self._stage_name))
        last_watermark_value = ""  
        with self._dao.get_only_connection as conn:
            cursor = conn.cursor(DictCursor)
            last_iteration_query = self._generate_query_for_max_watermark(table_name)
            #last_watermark = cursor.execute(last_iteration_query).fetchone()[0]
            last_watermark = cursor.execute(last_iteration_query).fetchone()
            if last_watermark != None:
                for column in self._watermark_column.split(','):
                    last_watermark_value = last_watermark_value + column.strip() + '~#$' + GenericFunctions.datetime_to_string(last_watermark[column.strip()]) + ','
                #last_watermark_value = GenericFunctions.datetime_to_string(last_watermark) 
            
        return last_watermark_value[:-1]

    def _generate_query(self, table_name) -> None:
        raise NotImplementedError
