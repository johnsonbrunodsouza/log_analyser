class QueryTemplates:

    get_current_state_template = '''
    SELECT * FROM  {{table_name}} as c
    WHERE c.job_id='{{job_id}}'
    {% if entity %}
            and c.source_entity='{{entity}}'
        {% if entity_filter %}
            and c.source_filter='{{entity_filter}}'
        {% endif %}
    {% endif %}
    '''

    get_first_record_for_table_in_curent_run = '''
    SELECT * FROM {{table_name}}
    WHERE source_entity='{{entity}}'
    AND run_id = '{{runid}}'
    AND STATUS in ('success','queuedforimport')
    ORDER BY CREATED_ON 
    LIMIT 1
    '''

    get_last_record_template = '''
    SELECT last_record_pulled FROM {{table_name}}
    WHERE source_entity='{{entity}}'    
    AND STATUS = 'success'
    AND last_record_pulled is not null
    ORDER BY CREATED_ON desc 
    LIMIT 1
    '''

    get_processing_history_template = '''
    SELECT distinct c.source_entity
    FROM {{table_name}}  as c
    WHERE c.source_name='{{source_name}}' 
        and c.manifest_name='{{manifest_name}}'
    '''

    netezza_source_template = '''
    {% if checksum_function == 'hash'%}
    SELECT * , {{checksum_function}}('{{checksum_column}}',0) as ck_sum 
    {% elif checksum_function == 'hash8' %}
    SELECT * , {{checksum_function}}('{{checksum_column}}') as ck_sum 
    {% else %}
    SELECT * , CAST(random()* 100000 AS INT) as ck_sum 
    {% endif %}
    FROM {{table_name}}
    {% if watermark_flag %}
        WHERE 
            {{watermark_column}} > {{watermark_offset}}
            {% if last_record_pulled_flag %}
                AND {{watermark_column}}  > {{last_record_pulled}} 
            {% endif %}
        ORDER BY {{watermark_column}}
    {% endif %}
    {% if query_limit %}
        LIMIT {{query_limit}}
    {% endif %}
    '''

    netezza_get_columns_template = '''
    SELECT COLUMN_NAME, DATA_TYPE
    FROM INFORMATION_SCHEMA.COLUMNS  
    WHERE
    TABLE_SCHEMA ||'.'||TABLE_NAME  = '{{table_name}}'
    '''

    netezza_generate_external_table_template = '''
    CREATE EXTERNAL TABLE {{external_table_name}}({{cols}})
    USING ( DATAOBJECT ('{{unload_file}}')  DELIMITER ','
    REMOTESOURCE '{{driver_type}}' INCLUDEHEADER);
    '''

    netezza_external_source_template = '''
    INSERT INTO {{external_table_name}}  
    {% if checksum_function == 'hash'%}
    SELECT * , {{checksum_function}}('{{checksum_column}}',0) as ck_sum 
    {% elif checksum_function == 'hash8' %}
    SELECT * , {{checksum_function}}('{{checksum_column}}') as ck_sum 
    {% else %}
    SELECT * , CAST(random()* 100000 AS INT) as ck_sum 
    {% endif %}
    FROM {{table_name}}
    {% if watermark_flag %}
        WHERE 
            {{watermark_column}} > {{watermark_offset}}
            {% if last_record_pulled_flag %}
                AND {{watermark_column}}  > {{last_record_pulled}} 
            {% endif %}
        ORDER BY {{watermark_column}}
    {% endif %}
    {% if query_limit %}
        LIMIT {{query_limit}}
    {% endif %}
    '''

    oracle_source_template = '''
        {% if checksum_function == 'standard_hash'%}
        SELECT {{table_name}}.* , {{checksum_function}}({{checksum_column}},'SHA256') as ck_sum 
        {% elif checksum_function == 'ora_hash' %}
        SELECT {{table_name}}.* , {{checksum_function}}({{checksum_column}}) as ck_sum 
        {% else %}
        SELECT {{table_name}}.* , dbms_random.value(100000000000, 999999999999) as ck_sum 
        {% endif %}
        FROM {{table_name}}
        {% if watermark_flag %}
            WHERE 
                {{watermark_column}} > {{watermark_offset}}
                {% if last_record_pulled_flag %}
                    AND {{watermark_column}}  > {{last_record_pulled}}
                {% endif %}
            ORDER BY {{watermark_column}}
        {% endif %}
        {% if query_limit %}
             FETCH NEXT {{query_limit}} ROWS ONLY
        {% endif %}
        '''

    hive_source_template = '''
    {% if checksum_function == 'md5'%}
    SELECT * , {{checksum_function}}({{checksum_column}}) as ck_sum 
    {% else %}
    SELECT * 
    {% endif %}
    FROM {{table_name}}
    {% if watermark_flag %}
        WHERE 
            {{watermark_column}} > {{watermark_offset}}
            {% if last_record_pulled_flag %}
                AND {{watermark_column}}  > {{last_record_pulled}} 
            {% endif %}
        ORDER BY {{watermark_column}}
    {% endif %}
    {% if query_limit %}
        LIMIT {{query_limit}}
    {% endif %}
    '''

    bq_get_record_count = '''
        select row_count from {{dataset_id}}.__TABLES__ where table_id = '{{table_name}}'
    '''
    bq_source_template = '''
        SELECT 
        {% if checksum_function == 'standard_hash' -%}
         {{query_select_list}} , {{checksum_function}}({{checksum_column}},'SHA256') as ck_sum 
        {% elif checksum_function == 'crc32' -%}
         {{query_select_list}} , {{checksum_function}}({{checksum_column}}) as ck_sum 
        {% else -%}
         {{query_select_list}}
        {%- endif %}
        FROM {{table_name}} 
        {% if watermark_flag -%}             
                {% if merge_flag and not incrementalload -%}
                    {% if last_record_pulled_flag -%}                        
                        WHERE 
                        {% for key, value in watermark_column.items() -%}
                            {{space}}{{key}} > ''{{value}}'' OR 
                        {%- endfor %}
                    {%- endif %}
                {% else -%}
                    {% if year_month_iteration_flag -%}
                        {% if year_value != 'nan' -%}
                            WHERE EXTRACT(YEAR FROM {{watermark_column}}) = {{year_value}} AND EXTRACT(MONTH FROM {{watermark_column}}) = {{month_value}}    
                        {% else -%}
                            WHERE {{watermark_column}} is null
                        {%- endif %} 
                    {% else -%}
                        {% if year_iteration_flag -%}
                            {% if year_value != 'nan' -%}
                                WHERE EXTRACT(YEAR FROM {{watermark_column}}) = {{year_value}}    
                            {% else -%}
                                WHERE {{watermark_column}} is null
                            {%- endif %}               
                        {%- endif %}                
                    {%- endif %}                    
                {%- endif %}                
        {%- endif %}
        '''
    
    bq_schema_template = '''
        select 
            column_name as ColumnName
        from benchmarking_tpc_ds.INFORMATION_SCHEMA.COLUMNS
        where table_catalog = '{{project_id}}'
        and table_schema = '{{database_name}}'
        and table_name = '{{table_name}}'
        order by ordinal_position;        
    '''

    teradata_fetch_iterations = '''
        SELECT YEAR({{watermark_column}}), MONTH({{watermark_column}}), count(*) as Total       
        FROM {{table_name}}
        group by 1,2 order by 1,2
    '''
    bq_fetch_iterations_new = '''    
        {% if iteration == 'Year' %}
            SELECT EXTRACT(YEAR FROM {{watermark_column}}), '*' as MonthIteration     
            FROM {{table_name}}
            {% if cdcmode == 'incremental' %}
                WHERE EXTRACT(YEAR FROM {{watermark_column}}) > {{last_watermark_year}}
            {% endif %}
            group by 1,2 order by 1,2
        {% else %}
                {% if iteration == 'SixMonths' %}
                     with cte_year as (
                                            select 
                                                distinct EXTRACT(YEAR FROM {{watermark_column}}) as YearValue 
                                            from {{table_name}}
                                            {% if cdcmode == 'incremental' %}
                                                {% if last_watermark_month <= 6 %}
                                                    WHERE EXTRACT(YEAR FROM {{watermark_column}}) >= {{last_watermark_year}}
                                                {% elif last_watermark_month > 6 %}
                                                    WHERE EXTRACT(YEAR FROM {{watermark_column}}) > {{last_watermark_year}}
                                                {% endif %}
                                            {% endif %}
                                      )
                        {% if cdcmode == 'incremental' %}
                            {% if last_watermark_month > 6 %}
                                select YearValue, '<=6', 1 as MonthIteration from cte_year
                                union 
                                select YearValue, '>6', 2 as MonthIteration from cte_year
                                order by 1, 3;
                            {% elif last_watermark_month <= 6 %}
                                select YearValue, '<=6', 1 as MonthIteration from cte_year where YearValue <> {{last_watermark_year}}
                                union 
                                select YearValue, '>6', 2 as MonthIteration from cte_year
                                order by 1, 3;
                            {% endif %}   
                        {% else %}
                            select YearValue, '<=6', 1 as MonthIteration from cte_year
                            union 
                            select YearValue, '>6', 2 as MonthIteration from cte_year
                            order by 1, 3;
                        {% endif %}  
                {% endif %}
        {% endif %}
    '''

    bq_fetch_sizing_for_table = '''
        select 
            dataset_id as DatabaseName,
            table_id as TableName,
            sum(size_bytes)/pow(10,9) as SizeOfTable,
            case 
                when sum(size_bytes)/pow(10,9) < 100 then 'Full'
                when sum(size_bytes)/pow(10,9) between 100 and 500 then 'Year'
                else 'SixMonths'
            end as Iteration 
        from {{database_name}}.__TABLES__
        group by 1,2;
    '''
    teradata_get_primary_keys = '''
        select {{keycolumn}}
        from {{keytablename}} 
        where {{keytablenamecolumn}} = '{{table_name}}'
    '''

    teradata_update_source_to_success = '''
        update {{state_manager_table}}
        set status = 'success',
        updated_on = '{{last_update}}'
        where state_id = '{{state_id}}'
    '''

    update_iteration_on_summary = '''
        update {{summary_table}}
        set import_iterations_completed = import_iterations_completed + 1,
        update_date = '{{last_update}}'
        where run_id = '{{run_id}}'
        and table_name = '{{table_name}}'
        and manifest_name = '{{manifest}}'
    '''
    
    snowflake_fetch_max_watermark_values = '''
        with cte as (
                        select MAX({{watermark_column}}) as MaxValue from {{table_name}}
                    )
        select 
            DATE_PART(YEAR, MaxValue) as YearValue, 
            DATE_PART(MONTH, MaxValue) as MonthValue
        from cte;
    '''
    
    snowflake_get_missing_watermarks = '''
        select 
            {% for column in columns %}
                {% if not loop.last %}
                    MAX({{column}}) as {{column}},
                {% else %}
                    MAX({{column}}) as {{column}}
                {% endif %}
            {% endfor %}
        from {{table_name}}
    '''

    snowflake_summary_table_insert = '''
        insert into {{summary_table}} values (
            '{{run_id}}',
            '{{manifest}}',
            '{{table_name}}',
            {{export_iterations}},
            0,
            '{{create_date}}',
            '{{update_date}}'
        )
    '''

    get_run_id_from_summary_using_manifest = '''
        select run_id
        from {{summary_table}}
        where MANIFEST_NAME = '{{manifest}}'
        and create_date = (
            select max(create_date) as MaxCreateDate
            from {{summary_table}}
            where MANIFEST_NAME = '{{manifest}}'            
        )
    '''

    get_pending_iterations_from_state_manager_summary = '''
        select sum(IterationsPending) from 
        (
            select count(*) as IterationsPending
            from {{summary_table}}
            where run_id = '{{run_id}}'
            and manifest_name = '{{manifest_name}}'
            and import_iterations_completed < export_iterations
            union
            select {{table_count}} - count(*) as IterationsPending
            from {{summary_table}}
            where run_id = '{{run_id}}'
            and manifest_name = '{{manifest_name}}'
        )
    '''

    get_state_manager_entries_to_begin_import = '''
        select distinct
            sm.*,
            summ.export_iterations as EXPORT_ITERATIONS,
            summ.import_iterations_completed as IMPORT_ITERATIONS_COMPLETED
        from {{summary_table}} summ
        inner join {{state_manager_table}} sm
            on sm.run_id = summ.run_id
            and sm.manifest_name = summ.manifest_name
            and sm.source_entity = summ.table_name
            and sm.status = 'queuedforimport'
        where summ.run_id = '{{run_id}}'
        and summ.manifest_name = '{{manifest_name}}'
        and summ.import_iterations_completed < summ.export_iterations
        order by sm.source_entity, sm.updated_on
    '''
    
    dashboard_get_unique_column_values = '''
        select 
            distinct {{column_name}} as {{column_alias}}
        from {{table_name}} 
    '''

    dashboard_get_summary_based_on_filters = '''
        select 
            summ.run_id,
            summ.manifest_name,
            summ.table_name,
            case
                when contains(listagg(distinct sm.overallstatus, ',') within group (order by sm.overallstatus), 'Failed') then 'Failed'
                when contains(listagg(distinct sm.overallstatus, ',') within group (order by sm.overallstatus), 'In Progress') then 'In Progress'
                when contains(listagg(distinct sm.overallstatus, ',') within group (order by sm.overallstatus), 'Unknown') or listagg(distinct sm.overallstatus, ',') within group (order by sm.overallstatus) = '' then 'Unknown'
                else listagg(distinct sm.overallstatus, ',') within group (order by sm.overallstatus)
            end as OVERALLSTATUS,
            sum(sm.SinkRecordCount) as RecordCount,
            sum(sm.sourcingtime) as SourcingTime,
            sum(sm.sinkingtime) as SINKINGTIME,
            sum(sm.sinkattempts) as SINKATTEMPTS,
            summ.create_date,
            summ.export_iterations as PLanned_Export_Iterations,
            summ.import_iterations_completed,
            summ.export_iterations - summ.import_iterations_completed as Pending_iterations
        from state_manager_summary summ
        left join consolidatedstatemangerentries as sm
            on summ.run_id = sm.run_id
            and summ.manifest_name = sm.manifest_name
            and summ.table_name = sm.Source_Table_name
        where summ.create_date between '{{start_date}}' and '{{end_date}}'
        and (
                (
                    {{tablelist}} != ''
                    and summ.table_name in ({{tables}})
                )
                or
                (
                    {{tablelist}} = ''
                )
            )
        and (
                (
                    {{manifestlist}} != ''
                    and summ.manifest_name in ({{manifests}})
                )
                or
                (
                    {{manifestlist}} = ''
                )
            )
        and (
                (
                    {{statuslist}} != ''
                    and OVERALLSTATUS in ({{status}})
                )
                or
                (
                    {{statuslist}} = ''
                )
            )    
        group by summ.run_id, summ.manifest_name, summ.table_name, summ.create_date, summ.export_iterations, summ.import_iterations_completed, Pending_iterations
    '''
    dashboard_get_details_based_on_filters = '''
        select sm.*            
        from {{summary_table}} summ
        left join consolidatedstatemangerentries as sm
            on summ.run_id = sm.run_id
            and summ.manifest_name = sm.manifest_name
            and summ.table_name = sm.Source_Table_name
        where summ.create_date between '{{start_date}}' and '{{end_date}}'
        and (
                (
                    {{tablelist}} != ''
                    and summ.table_name in ({{tables}})
                )
                or
                (
                    {{tablelist}} = ''
                )
            )
        and (
                (
                    {{manifestlist}} != ''
                    and summ.manifest_name in ({{manifests}})
                )
                or
                (
                    {{manifestlist}} = ''
                )
            )
        and (
                (
                    {{statuslist}} != ''
                    and sm.OVERALLSTATUS in ({{status}})
                )
                or
                (
                    {{statuslist}} = ''
                )
            )  
    '''