import sys
sys.path.append('C:\BCBS_HDM')