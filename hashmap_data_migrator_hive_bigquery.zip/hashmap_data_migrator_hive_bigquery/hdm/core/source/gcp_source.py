# Copyright © 2020 Hashmap, Inc
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
import json
import os
from sys import stderr
import pandas as pd
import enum
import datetime
from jinjasql import JinjaSql
import subprocess
from sqlalchemy import table, true
import yaml
from hdm.core.query_templates.query_templates import QueryTemplates
from hdm.core.utils.project_config import ProjectConfig
from hdm.core.utils.generic_functions import GenericFunctions
from hdm.core.source.rdbms_source import RDBMSSource
from hdm.core.dao.gcp import GCP
from google.cloud import bigquery

class HashFunction(enum.Enum):
    STANDARD_HASH = "CRC32"

class GCPSource(RDBMSSource):    
    def consume(self, **kwargs):
        self._logger.info("Retrieving data from %s", self.__table)
        return self._run(**kwargs)

    def __init__(self, **kwargs):        
        super().__init__(**kwargs)
        # self._is_running = True
        self.__connection_choice = kwargs['workflow']['source']['conf']['env']
        self.__iteration = kwargs['iteration']        
        self.__table = kwargs['table']['table_name']
        self.__merge = False
        self.__incrementalload = False
        self.__last_iteration = kwargs['last_iteration']
        if kwargs['table']['cdc']['mode']:
            #if kwargs['table']['cdc']['mode'].lower() != 'incremental' or (kwargs['table']['cdc']['mode'].lower() == 'incremental' and self.__last_iteration):
            if kwargs['table']['cdc']['mode'].lower() in ['merge','deleteinsert'] or (kwargs['table']['cdc']['mode'].lower() == 'incremental' and self.__last_iteration):
                self.__merge = True
            if kwargs['table']['cdc']['mode'].lower() == 'incremental':
                self.__incrementalload = True
        self.__year = kwargs['year']
        self.__month = kwargs['month']
        self.__watermark = kwargs['table']['watermark']       
        self._entity = self.__table
        self._entity_filter = kwargs['table']['watermark']['column']   
        self.__query_select_list = kwargs['query_select_list']
        self.__query = ""
        self.__manual_query = kwargs['table'].get('query','')
        self.__compression = ""
        if 'compression' in kwargs['table']:
            if kwargs['table']['compression']:
                self.__compression = "GZIP"
        self._source_name = kwargs['workflow']['source']['name']
        self._sink_name = kwargs['workflow']['sink']['name']        
        self.__bucket_name = kwargs['conn_conf'][kwargs['workflow']['sink']['conf']['source_env']]['bucket_name']
        self.__keytablename = ""
        self.__keytablenamecolumn = ""
        self.__keycolumn = ""
        self.__merge_mode = ""
        if 'cdc' in kwargs['table']:
            if not kwargs['table']['cdc']['mode'] == None:
                self.__keytablename = kwargs['table']['cdc']['keytable']['tablename']
                self.__keytablenamecolumn = kwargs['table']['cdc']['keytable']['tablenamecolumn']
                self.__keycolumn = kwargs['table']['cdc']['keytable']['keycolumn']
                self.__merge_mode = kwargs['table']['cdc']['mode']
        self.__year_month_iteration = kwargs['year_month_iteration']
        self.__year_iteration = kwargs['year_iteration']
        self.__format = ''
        if 'exportformat' in kwargs['table']:
            self.__format = kwargs['table']['exportformat']
        else:
            self.__format = 'CSV'
        self.filenamewildcard = ''
        if self.__format.upper() != 'CSV':
            self.filenamewildcard = '*'
        else:
            self.__filenamewildcard = "*.csv"

        if self.__compression:
            self.__filenamewildcard = f"{self.__filenamewildcard}.gz"
        self.__extraction_method = 'extract'
        if 'exportmethod' in kwargs['table']:
            self.__extraction_method = kwargs['table']['exportmethod'].lower()
        else:
            self.__extraction_method = 'extract'
        self.__project = kwargs['table']['project']
        self.__location = kwargs['table']['location']

    def _get_data(self, **kwargs):                        
        data_dict = {}
        data_dict['record_count'] = self.__get_data_with_bq_export()   
        data_dict['sink_entity'] = f"gs://{self.__bucket_name}/{GenericFunctions.table_to_folder(self.__table)}/{self.__iteration}/"         
        data_dict['primarykeys'] = []                
        
        return data_dict

    def __get_data_with_bq_export(self):

        with GCP(connection=self.__connection_choice).connection as conn:
            if self.__extraction_method == 'export':
                self.__build_query()
                query_job = f"""EXPORT DATA OPTIONS (
                                                        uri='gs://{self.__bucket_name}/{GenericFunctions.table_to_folder(self.__table)}/{self.__iteration}/{self.__filenamewildcard}',
                                                        format='{self.__format}',
                                                        overwrite=true,
                                                        header=false,
                                                        fielddelimiter=';'
                            """
                if self.__compression:
                    query_job = f"{query_job}, compression='GZIP')"
                else:
                    query_job = f"{query_job} )"
                
                query_job = f"{query_job} AS {self.__query}"
                export_job = conn.query(query_job)
            else:
                dataset_ref = bigquery.DatasetReference(self.__project, self.__table.split('.')[0])
                table_ref = dataset_ref.table(GenericFunctions.table_name_only(self.__table))
                job_config = bigquery.job.ExtractJobConfig()
                if self.__compression:
                    job_config.compression = bigquery.Compression.GZIP
                export_job = conn.extract_table(table_ref,
                                                 f'gs://{self.__bucket_name}/{GenericFunctions.table_to_folder(self.__table)}/{self.__iteration}/{self.__filenamewildcard}',
                                                 location=self.__location, job_config=job_config
                   )
            
            export_job.result()               
            rc_df = conn.query(self.__build_query_for_record_count()).to_dataframe()
            record_count = rc_df.iloc[0, 0]
        
        return record_count

    def __build_query_for_record_count(self):
        query_template = QueryTemplates.bq_get_record_count
        params = {            
            'dataset_id': self.__table.split('.')[0],
            'table_name': GenericFunctions.table_name_only(self.__table)
        }
        j = JinjaSql(param_style='pyformat')
        j.env.trim_blocks = True
        j.env.lstrip_blocks = True
        query, bind_params = j.prepare_query(query_template, params)
        query = query % bind_params
        return query


    def __build_query(self) -> None:
        """
        builds query.
        checksum_methods:
        default method: generates random numbers as checksum value
        Returns: none
        """
        if self.__manual_query != None:
            self.__query = self.__manual_query
            return

        _checksum_flag, _query_limit, _watermark_flag, _last_record_pulled_flag, _last_record_pulled, _checksum_function, \
            _checksum_column, _watermark_column, _watermark_offset, _watermark_offset_flag = (None,) * 10

        # Checksum
        if self.__checksum and self.__checksum['function'] and self.__checksum['column']:
            _checksum_flag = 'CRC32' if self.__checksum['function'].lower() == HashFunction.STANDARD_HASH.value else ''
            _checksum_function = self.__checksum['function'].lower()
            _checksum_column = self.__checksum['column'].lower()

        # Watermark        
        _watermark_column = {}

        if self.__watermark and self.__watermark['column']:
            #_watermark_flag, _watermark_column = True, self.__watermark['column']
            _watermark_flag = True
            for column in self.__watermark['column'].split(','):
                _watermark_column[column.strip()] = ""

            if self.__watermark['offset'] and self.__watermark['offset'] != "":
                _watermark_offset_flag, _watermark_offset = True, self.__watermark['offset']

            if self._last_record_pulled:
                for key_value in self._last_record_pulled.split(','):
                    #if self.__watermark['column'] == key_value.split("~#$")[0]:
                    if key_value.split("~#$")[0] in _watermark_column:
                        #_last_record_pulled_flag, _last_record_pulled = True, key_value.split("~#$")[1]
                        _last_record_pulled_flag = True
                        #_last_record_pulled.append(key_value.split("~#$")[1])
                        _watermark_column[key_value.split("~#$")[0]] = key_value.split("~#$")[1]
                        #break

        # Query_limit
        if ProjectConfig.query_limit():
            _query_limit = ProjectConfig.query_limit()
                   

        query_template = QueryTemplates.bq_source_template
        params = {
            #'table_name': self.__table,
            #'table_name': '.'.join(['"' + x + '"' for x in self.__table.split('.')]),
            'table_name': GenericFunctions.table_name_with_quotes(self.__table),
            'watermark_flag': _watermark_flag,
            'watermark_column': _watermark_column if self.__merge_mode not in ['full','incremental'] else self.__watermark['column'].split(',')[0].strip() if self.__watermark['column'] else '',
            'watermark_offset_flag': _watermark_offset_flag,
            'watermark_offset': _watermark_offset,
            'checksum_function': _checksum_function,
            'checksum_column': _checksum_column,
            'last_record_pulled_flag': _last_record_pulled_flag,
            #'last_record_pulled': _last_record_pulled,
            'query_limit': _query_limit,
            'merge_flag': self.__merge,
            'year_value': self.__year,
            'month_value': self.__month,
            'year_month_iteration_flag': self.__year_month_iteration,
            'query_select_list': self.__query_select_list,
            'year_iteration_flag': self.__year_iteration,
            'incrementalload': self.__incrementalload,
            'space': " "
        }
        j = JinjaSql(param_style='pyformat')
        j.env.trim_blocks = True
        j.env.lstrip_blocks = True
        query, bind_params = j.prepare_query(query_template, params)
        self.__query = query % bind_params
        if self.__query.rstrip()[-2:] == "OR":
            self.__query = self.__query.rstrip()[:-2]