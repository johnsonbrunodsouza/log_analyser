import sys
sys.path.append('C:/NTTDATA/Deutche_Bank/hashmap_data_migrator_hive_bigquery')