#  Copyright © 2020 Hashmap, Inc
#  #
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#  #
#      http://www.apache.org/licenses/LICENSE-2.0
#  #
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.

# Copyright © 2020 Hashmap, Inc
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import sys
sys.path.append('C:/NTTDATA/Deutche_Bank/hashmap_data_migrator_hive_bigquery')
import streamlit as st
from hdm.core.dao.snowflake import Snowflake
import os
import json
import snowflake.connector as connector
from hdm.core.query_templates.query_templates import QueryTemplates
from jinjasql import JinjaSql
from hdm.core.utils.project_config import ProjectConfig
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime as dt
import calendar as clndr
import dateutil.relativedelta
import calendar
from datetime import timedelta

def get_next_day():
    yyyy = dt.now().year
    mm = dt.now().month
    dd = dt.now().day
    res = calendar.monthrange(yyyy, mm)

    if res[1] == dd:
        if mm == 12:
            yyyy = yyyy + 1
            mm = 1
            dd = 1
        else:
            mm = mm + 1
            dd = 1
    else:
        dd = dd + 1

    return yyyy, mm, dd

def fetchdata(query_template, startdate, enddate, tables, tablelist, manifests, manifestlist, status, statuslist):
    params = {
        'summary_table': ProjectConfig.state_manager_summary_table_name(),
        'state_manager_table': ProjectConfig.state_manager_table_name(),
        'start_date': startdate,
        'end_date': enddate,
        'tables': tables,
        'tablelist': tablelist,
        'manifests': manifests,
        'manifestlist': manifestlist,
        'status': status,
        'statuslist': statuslist
    }
    j = JinjaSql(param_style='pyformat')
    query, bind_params = j.prepare_query(query_template, params)
    query = query % bind_params
    try:
        with getSnowflakeconnection() as conn:        
            cursor = conn.cursor()
            cursor.execute(query)
            columns = cursor.description
            result_set = [{columns[row_index][0]: value for row_index, value in enumerate(record)} for record in cursor.fetchall()]
            df_result_set = pd.DataFrame(result_set)
    except Exception as e:
        st.error(f"Error: {str(e)}")
        raise 
    finally:
        cursor.close()
    return df_result_set

def dashboard_get_unique_column_values(query_template, table_name, column_name, column_alias):
    params = {
        'table_name': table_name,
        'column_name': column_name,
        'column_alias': column_alias
    }
    j = JinjaSql(param_style='pyformat')
    query, bind_params = j.prepare_query(query_template, params)
    query = query % bind_params
    try:
        with getSnowflakeconnection() as conn:        
            cursor = conn.cursor()
            data = cursor.execute(query).fetchall()   
    except Exception as e:
        st.error(f"Error: {str(e)}")
        raise 
    finally:
        cursor.close()
    return pd.DataFrame(data)

def test_connection(connection) -> bool:
    if not connection:
        return False

    with connection.cursor() as cursor:
        cursor.execute("SELECT 1")
        if not len(cursor.fetchone()) > 0:
            return False

        return True

def getSnowflakeconnection():
    try:
        connection = connector.connect(
            user=st.session_state[f"{statemanager}_user"],
            password=st.session_state[f"{statemanager}_password"],
            account=st.session_state[f"{statemanager}_account"],
            authenticator=st.session_state[f"{statemanager}_authenticator"],
            warehouse=st.session_state[f"{statemanager}_warehouse"],
            database=st.session_state[f"{statemanager}_database"],
            schema=st.session_state[f"{statemanager}_schema"],
            role=st.session_state[f"{statemanager}_role"],
            login_timeout=10
        )

        if not test_connection(connection):
            raise

    except Exception as e:
        st.exception(f"Exception in connection to Snowflake: {str(e)}")

    return connection

def create_widgets(connection_key):
    connection_profile = {}
    for widget in conn_params[connection_key]['params']:
        if widget['widget_type'] == "text_input":
            if 'environment' == widget['param_name']:
                st.text_input(label=widget['widget_name'], value=widget['default'], disabled=eval(widget['disabled']), key=f"{connection_key}_{widget['param_name']}")
            elif 'driver' not in widget['param_name']:
                connection_profile[widget['param_name']] = str(st.text_input(label=widget['widget_name'], value=widget['default'], disabled=eval(widget['disabled']), key=f"{connection_key}_{widget['param_name']}"))            
            else:
                if 'driver' not in connection_profile:
                    connection_profile['driver'] = {}
                connection_profile['driver'][widget['param_name'].replace('driver','')] = str(st.text_input(label=widget['widget_name'], value=widget['default'], disabled=eval(widget['disabled']), key=f"{connection_key}_{widget['param_name']}"))
        elif widget['widget_type'] == "password":
            connection_profile[widget['param_name']] = str(st.text_input(label=widget['widget_name'], value=widget['default'], disabled=eval(widget['disabled']), key=f"{connection_key}_{widget['param_name']}", type="password"))
        elif widget['widget_type'] == "selectbox":
            connection_profile[widget['param_name']] = str(st.selectbox(label=widget['widget_name'], options=widget['options'], disabled=eval(widget['disabled']), index=widget['default'], key=f"{connection_key}_{widget['param_name']}"))
        elif widget['widget_type'] == "text":
            connection_profile[widget['param_name']] = str(st.text(body=widget['widget_name']))
    return connection_profile

def check_for_empty_params(config):
    missingconfigs = []
    for key in config.keys():
        if config[key] == "" and key != 'database':
            missingconfigs.append(f"Missing config for {key}.")
    return missingconfigs

def test_state_manager_connection(target, target_connection):        
    try:
        success = True
        missingconfigs = check_for_empty_params(target_connection)
        if not missingconfigs:  
            getSnowflakeconnection()
            st.info(f"{target} Connection Succeded")
        else:
            st.error(f"{target} - {missingconfigs}")
            success = False
    except Exception as e:
        st.error(f"Error: {str(e)}")
        success = False
    return success

def ChngDtRadio():
    if st.session_state['DateRange'] == "Today":
        st.session_state.StartDate = dt.now()
        tomorrow = dt.today() + timedelta(days=1)
        dd = tomorrow.day
        mm = tomorrow.month
        yyyy = tomorrow.year
        #st.session_state.EndDate = dt(dt.now().year, dt.now().month, dt.now().day + 1)
        st.session_state.EndDate = dt(yyyy, mm, dd)
    elif st.session_state['DateRange'] == "This Week":
        myclndr = clndr.monthcalendar(dt.now().year, dt.now().month)
        if dt.now().month<12:
            myclndr_next_month = clndr.monthcalendar(dt.now().year, dt.now().month+1)
        else:
            myclndr_next_month = clndr.monthcalendar(dt.now().year+1, 1)
        tdy = dt.now().day
        for i in range(len(myclndr)):
            if tdy in myclndr[i]:
                st.session_state.StartDate = dt(dt.now().year, dt.now().month, myclndr[i][0])
                if myclndr[i][6]!=0:
                    st.session_state.EndDate = dt(dt.now().year, dt.now().month, myclndr[i][6])
                else:
                    if dt.now().month!=12:
                        st.session_state.EndDate = dt(dt.now().year, dt.now().month+1, myclndr_next_month[0][6])
                    else:
                        st.session_state.EndDate = dt(dt.now().year+1, 1, myclndr_next_month[0][6])
                break
    elif st.session_state['DateRange'] == "This Month":
        st.session_state.StartDate = dt(dt.now().year, dt.now().month, 1)
        st.session_state.EndDate = dt(dt.now().year, dt.now().month, clndr.monthrange(dt.now().year, dt.now().month)[1])
    elif st.session_state['DateRange'] == "Last One Month":
        st.session_state.StartDate = dt.now() - dateutil.relativedelta.relativedelta(months=1)
        st.session_state.EndDate = dt.now()
    elif st.session_state['DateRange'] == "Last 3 Months":
        st.session_state.StartDate = dt.now() - dateutil.relativedelta.relativedelta(months=3)
        st.session_state.EndDate = dt.now()
    elif st.session_state['DateRange'] == "Last 6 Months":
        st.session_state.StartDate = dt.now() - dateutil.relativedelta.relativedelta(months=6)
        st.session_state.EndDate = dt.now()
    elif st.session_state['DateRange'] == "Year to Date":
        st.session_state.StartDate = dt(dt.now().year, 1, 1)
        st.session_state.EndDate = dt.now()

def create_filter_widgets():
    datrange = st.radio(label="Date Ranges:", options=["Today", "This Week", "This Month", "Last One Month", "Last 3 Months", "Last 6 Months", "Year to Date"], key="DateRange", horizontal=True, on_change=ChngDtRadio, index=0)
    startdate = st.date_input(label="Start Date", key="StartDate")
    #enddate = st.date_input(label="End Date", key="EndDate", value=dt(dt.now().year, dt.now().month, dt.now().day + 1))
    tomorrow = dt.today() + timedelta(days=1)
    dd = tomorrow.day
    mm = tomorrow.month
    yyyy = tomorrow.year
    enddate = st.date_input(label="End Date", key="EndDate", value=dt(yyyy,mm,dd))
    tables = st.multiselect(label="Table Names", options=st.session_state['tablenames'])
    manifests = st.multiselect(label="Manifest Names", options=st.session_state['manifestnames'])
    status = st.multiselect("Status", options=['Completed', 'Failed', 'In Progress', 'Unknown'])
    st.markdown('**Optional Charts:**')
    fetchdistributions = st.checkbox(label="Include Distributions", value=False, key="FetchDistributions")
    recordcountsbytableovertime = st.checkbox(label="Record Counts by Table over time", value=False, key="recordcountsbytableovertime")
    exportdurationbytableovertime = st.checkbox(label="Export Duration by Table over time", value=False, key="exportdurationbytableovertime")
    importdurationbytableovertime = st.checkbox(label="Import Duration by Table over time", value=False, key="importdurationbytableovertime")
    # fetchlatest = st.checkbox(label="Fetch Latest Only", value=False, key="FetchLatestOnly")
    st.button("Fetch", key="RefreshDashboard")
    return startdate, enddate, tables, manifests, status, fetchdistributions, recordcountsbytableovertime, exportdurationbytableovertime, importdurationbytableovertime

def create_overall_status_chart(dashboarddatasummary, col1):
    if dashboarddatasummary.shape[0] > 0:
        grp = dashboarddatasummary.groupby('OVERALLSTATUS')
        dat = grp.agg({'OVERALLSTATUS': 'count'})
        dat['Status'] = dat.index   
        with col1:
            if dat.shape[0] > 0:
                fig = px.pie(dat, values='OVERALLSTATUS', names='Status', 
                            title='<b>Overall Status</b>', color='Status', 
                            color_discrete_map={
                                                    'Completed':'green',
                                                    'Failed':'red',
                                                    'Unknown':'orange'
                                                }
                            )
                st.plotly_chart(fig, theme=None)

def create_line_metric_over_time_chart(df, sortby, x, y, color, title):
    if df.shape[0] > 0:
        # with col:
        df = df.sort_values(by=sortby)
        fig = px.line(df, x=x, y=y, color=color, markers=True, title="<b>" + title + "</b>")
        fig.update_layout(
                            xaxis=dict(
                                rangeselector=dict(
                                    buttons=list([
                                        dict(count=1,
                                            label="1m",
                                            step="month",
                                            stepmode="backward"),
                                        dict(count=3,
                                            label="3m",
                                            step="month",
                                            stepmode="backward"),
                                        dict(count=6,
                                            label="6m",
                                            step="month",
                                            stepmode="backward"),
                                        dict(count=1,
                                            label="YTD",
                                            step="year",
                                            stepmode="todate"),
                                        dict(count=1,
                                            label="1y",
                                            step="year",
                                            stepmode="backward"),
                                        dict(step="all")
                                    ])
                                ),
                                rangeslider=dict(
                                    visible=True
                                ),
                                type="date"
                            )
                        )
        st.plotly_chart(fig, theme=None, use_container_width=True)

def create_plotly_metric(label, value, col, prefix, suffix, valueformat):
    with col:
        fig = go.Figure()
        fig.add_trace(go.Indicator(mode = "number", value = value, title= {"text": f"<span style='font-size:2em;color:gray'>{label}</span>"}, number={"valueformat": valueformat, "prefix": prefix, "suffix": suffix, "font": {"size": 40}}))
        st.plotly_chart(fig, theme=None, use_container_width=True)

def create_histogram_chart(df, col, color, x, title, color_discrete_map):
    if df.shape[0] > 0:
        with col:
            if color:
                fig = px.histogram(df, x=x, title="<b>" + title + "</b>", color='OVERALLSTATUS', color_discrete_map=color_discrete_map, text_auto='.2s')
            else:
                fig = px.histogram(df, x=x, title="<b>" + title + "</b>", histfunc="count", y="TABLE_NAME", text_auto='.2s')
            fig.update_traces(textfont_size=12, textangle=0, textposition="outside", cliponaxis=False)
            fig.update_layout(
                                xaxis=dict(
                                    rangeselector=dict(
                                        buttons=list([
                                            dict(count=1,
                                                label="1m",
                                                step="month",
                                                stepmode="backward"),
                                            dict(count=3,
                                                label="3m",
                                                step="month",
                                                stepmode="backward"),
                                            dict(count=6,
                                                label="6m",
                                                step="month",
                                                stepmode="backward"),
                                            dict(count=1,
                                                label="YTD",
                                                step="year",
                                                stepmode="todate"),
                                            dict(count=1,
                                                label="1y",
                                                step="year",
                                                stepmode="backward"),
                                            dict(step="all")
                                        ])
                                    ),
                                    rangeslider=dict(
                                        visible=True
                                    ),
                                    type="date"
                                ),
                                bargap=0.2
                            )
            # fig.update_layout(bargap=0.2)
            st.plotly_chart(fig, theme=None)

def apply_colors(val):
    if val == 'Failed':
        color = 'red'
    elif val == 'Completed':
        color = 'green'
    elif val == 'Unknown':
        color = 'orange'
    elif val == 'In Progress':
        color = 'brown'
    else:
        color= 'black'

    return 'color: %s' % color

def create_dataframes(df, subheader, use_container_width):
    st.subheader(subheader)
    st.dataframe(data=df.style.applymap(apply_colors), use_container_width=use_container_width)

def create_pending_iterations_chart(df):
    if df.shape[0] > 0:
        df1 = df[(df['PENDING_ITERATIONS'] > 0)]
        fig = go.Figure()
        fig.add_trace(go.Histogram(x=df['TABLE_NAME'],y=df['IMPORT_ITERATIONS_COMPLETED'], name="IMPORT_ITERATIONS_COMPLETED", texttemplate="%{y}", marker_color='green',textfont_size=10, histfunc='sum'))
        fig.add_trace(go.Histogram(x=df1['TABLE_NAME'],y=df1['PENDING_ITERATIONS'], name="PENDING_ITERATIONS", texttemplate="%{y}", marker_color='orange',  textfont_size=10, histfunc='sum'))
        fig.update_traces(textfont_size=12, textangle=0, textposition="outside", cliponaxis=False)
        fig.update_layout(
                            title_text="<b>" + "Status of Tables by Iterations" + "</b>",
                            xaxis_title_text='Table Name', # xaxis label
                            yaxis_title_text='Count', # yaxis label
                            bargap=0.2, 
                            bargroupgap=0.1,
                            barmode='stack'
                        )
        st.plotly_chart(fig, theme=None, use_container_width=True)

def create_box_plot(df, col, x, y, title):
    if df.shape[0] > 0:
        with col:
            fig = px.box(df, x=x, y=y, title="<b>" + title + "</b>")
            st.plotly_chart(fig, theme=None)

def refresh_filters():
    st.info("Fetching information for filters...")
    st.session_state['tablenames'] = dashboard_get_unique_column_values(
                                                                            QueryTemplates.dashboard_get_unique_column_values, 
                                                                            ProjectConfig.state_manager_summary_table_name(), 
                                                                            'TABLE_NAME', 'TableName'
                                                                       )
    st.session_state['manifestnames'] = dashboard_get_unique_column_values(
                                                                                QueryTemplates.dashboard_get_unique_column_values, 
                                                                                ProjectConfig.state_manager_summary_table_name(), 
                                                                                'MANIFEST_NAME', 'ManifestName'
                                                                          )
    st.info("Filters ready, please use the Dashboard tab for further information...")

def fetch_dashboard_data(startdate, enddate, tables, manifests, status):
    dashboarddatasummary = fetchdata(
                                        QueryTemplates.dashboard_get_summary_based_on_filters,
                                        startdate, 
                                        enddate, 
                                        ','.join([f"'{table}'" for table in tables]) if len(tables) > 0 else "''", 
                                        "'" + ','.join([f"{table}" for table in tables]) + "'" if len(tables) > 0 else "''",
                                        ','.join([f"'{manifest}'" for manifest in manifests]) if len(manifests) > 0 else "''", 
                                        "'" + ','.join([f"{manifest}" for manifest in manifests]) + "'" if len(manifests) > 0 else "''", 
                                        # fetchlatest,
                                        ','.join([f"'{statusval}'" for statusval in status]) if len(status) > 0 else "''",
                                        "'" + ','.join([f"{statusval}" for statusval in status]) + "'" if len(status) > 0 else "''"
                                    )
    dashboarddatadetails = fetchdata(
                                        QueryTemplates.dashboard_get_details_based_on_filters,
                                        startdate, 
                                        enddate, 
                                        ','.join([f"'{table}'" for table in tables]) if len(tables) > 0 else "''", 
                                        "'" + ','.join([f"{table}" for table in tables]) + "'" if len(tables) > 0 else "''",
                                        ','.join([f"'{manifest}'" for manifest in manifests]) if len(manifests) > 0 else "''", 
                                        "'" + ','.join([f"{manifest}" for manifest in manifests]) + "'" if len(manifests) > 0 else "''", 
                                        # fetchlatest,
                                        ','.join([f"'{statusval}'" for statusval in status]) if len(status) > 0 else "''",
                                        "'" + ','.join([f"{statusval}" for statusval in status]) + "'" if len(status) > 0 else "''"
                                    )

    if dashboarddatasummary.shape[0] > 0:
        dashboarddatasummary.fillna('', inplace=True)
        dashboarddatasummary[["SOURCINGTIME", "SINKINGTIME", "SINKATTEMPTS", "RECORDCOUNT"]] = dashboarddatasummary[["SOURCINGTIME", "SINKINGTIME", "SINKATTEMPTS", "RECORDCOUNT"]].apply(pd.to_numeric)
        
    if dashboarddatadetails.shape[0] > 0:
        dashboarddatadetails.fillna('', inplace=True)

    return dashboarddatasummary, dashboarddatadetails



st.set_page_config(layout="wide", page_title="NTT Data Migrator Dashboard")
st.title("NTT Data Migrator Dashboard")
conn_params = json.load(open(os.path.join(os.path.split(os.path.abspath(__file__))[0], "widgets.json")))
statemanager = "SnowflakeStateManager"
if 'connectionsuccess' not in st.session_state:
    st.session_state['connectionsuccess'] = False
connections, dashboard = st.tabs(["🔗 Connections", "📈 Dashboard"])

with connections:          
    with st.expander("State Manager", expanded=False):
        state_manager_connection = create_widgets(statemanager)
        if st.button("Refresh Filters", key="ActivateFilters"):
            with st.spinner("Refreshing..."):
                st.session_state['connectionsuccess'] = test_state_manager_connection('state_manager', state_manager_connection)
                if st.session_state['connectionsuccess']:
                    refresh_filters()

with dashboard:
    with st.expander("Filters", expanded=True):
        if st.session_state['connectionsuccess']:
            startdate, enddate, tables, manifests, \
            status, fetchdistributions, recordcountsbytableovertime, \
            exportdurationbytableovertime, importdurationbytableovertime = create_filter_widgets()            

    if 'RefreshDashboard' in st.session_state:
        if st.session_state.RefreshDashboard:
            with st.spinner("Fetching Information..."):
                dashboarddatasummary, dashboarddatadetails = fetch_dashboard_data(startdate, enddate, tables, manifests, status)                
                graphs, data = st.tabs(["📊 Analysis", "🗃 Data"])
                                  
                with graphs:
                    col1, col2 = st.columns(spec=2, gap="large")
                    create_overall_status_chart(dashboarddatasummary, col1)
                    create_histogram_chart(dashboarddatasummary, col2, 'TABLE_NAME', 'CREATE_DATE', 'Status of Tables by time', {'Completed':'green','Failed':'red','Unknown':'orange'})                    
                    create_pending_iterations_chart(dashboarddatasummary)
                    if st.session_state['recordcountsbytableovertime']:
                        create_line_metric_over_time_chart(dashboarddatasummary, 'CREATE_DATE', 'CREATE_DATE', 'RECORDCOUNT', 'TABLE_NAME', "Record Counts by Table over time")                    
                    if st.session_state['exportdurationbytableovertime']:
                        create_line_metric_over_time_chart(dashboarddatasummary, 'CREATE_DATE', 'CREATE_DATE', 'SOURCINGTIME', 'TABLE_NAME', "Export Duration(in sec) by Table over time")
                    if st.session_state['importdurationbytableovertime']:
                        create_line_metric_over_time_chart(dashboarddatasummary, 'CREATE_DATE', 'CREATE_DATE', 'SINKINGTIME', 'TABLE_NAME', "Import Duration(in sec) by Table over time")                    
                    if st.session_state['FetchDistributions']:
                        col8, col9 = st.columns(spec=2, gap="large")
                        create_box_plot(dashboarddatasummary, col8, 'TABLE_NAME', 'SOURCINGTIME', 'Sourcing time distribition')
                        create_box_plot(dashboarddatasummary, col9, 'TABLE_NAME', 'SINKINGTIME', 'Sinking time distribition')
                    col3, col4, col5, col6, col7 = st.columns(spec=5, gap="large")
                    if dashboarddatasummary.shape[0] > 0:  
                        create_plotly_metric(label="Average Export Time", value=round(dashboarddatasummary['SOURCINGTIME'].mean(), 2), col=col3, prefix="", suffix="s", valueformat=".2f")
                        create_plotly_metric(label="Average Import Time", value=round(dashboarddatasummary['SINKINGTIME'].mean(), 2), col=col4, prefix="", suffix="s", valueformat=".2f")
                        create_plotly_metric(label="Total # of Rows Ingested", value=int(dashboarddatasummary['RECORDCOUNT'].sum()), col=col5, prefix="", suffix="", valueformat="")
                        create_plotly_metric(label="Total Export Time", value=int(dashboarddatasummary['SOURCINGTIME'].sum()), col=col6, prefix="", suffix="s", valueformat="")
                        create_plotly_metric(label="Total Import Time", value=int(dashboarddatasummary['SINKINGTIME'].sum()), col=col7, prefix="", suffix="s", valueformat="")                                   
                    
                with data:
                    create_dataframes(dashboarddatasummary, "Summary", True)
                    create_dataframes(dashboarddatadetails, "Details", True)  
                



