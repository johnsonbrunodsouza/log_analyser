#  Copyright © 2020 Hashmap, Inc
#  #
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#  #
#      http://www.apache.org/licenses/LICENSE-2.0
#  #
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.

# Copyright © 2020 Hashmap, Inc
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import sys
sys.path.append('C:/NTTDATA/Deutche_Bank/hashmap_data_migrator_hive_bigquery')
import subprocess
import streamlit as st
import os
import platform
import datetime
import shutil
import json
import pandas as pd
from string import Template
import yaml
from collections import OrderedDict
import plotly.graph_objects as go
from providah.factories.package_factory import PackageFactory as providah_pkg_factory
from hdm.core.dao.rdbms_dao import RdbmsDAO



template_select_summary = Template("""
                                        with summ as (
                                            select
                                                t.table_catalog as DatabaseName,
                                                t.table_Schema as SchemaName,
                                                t.table_name as TableName                                                   
                                            from $dataset.INFORMATION_SCHEMA.TABLES t
                                            where t.table_catalog = '$db' 
                                            and t.table_type = 'BASE TABLE'
                                        ),                                            
                                        metrics as (
                                            select 
                                                project_id as DatabaseName,
                                                dataset_id as SchemaName,
                                                table_id as TableName,
                                                row_count as RowCounts,
                                                size_bytes/pow(10,6) as TotalMB,
                                                datetime(TIMESTAMP_MILLIS(last_modified_time)) as LastModified
                                            from $dataset.__TABLES__
                                        )
                                        select
                                            summ.DatabaseName,
                                            summ.SchemaName,
                                            summ.TableName,                                                
                                            m.RowCounts,                                               
                                            m.TotalMB,                                                
                                            m.LastModified
                                        from summ                                             
                                        left join metrics m
                                            on summ.DatabaseName = m.DatabaseName
                                            and summ.SchemaName = m.SchemaName
                                            and summ.TableName = m.TableName;
                                                                                        
    """
    )

__template_select_table_summary = Template("  select   "
"       t.DatabaseName,   "
"       t.TableName, "
"       t.TableType, "
"       case when COALESCE (ts.TotalSize, partsize.TotalSize) is null then 0 else COALESCE (ts.TotalSize, partsize.TotalSize)/(1024*1024) end as TableSizeInMb, "
"       case when COALESCE(rowcount.RowCount, partrowcount.RowCount) is null then 0 else COALESCE(rowcount.RowCount, partrowcount.RowCount) end as RowCount, "
"       part.PartitionColumn, "
"       loc.Location "
"  from (  "
"        SELECT d.NAME as DatabaseName,  t.TBL_NAME as TableName, t.TBL_TYPE as TableType  "
"            FROM hive.TBLS t   "
"            inner join hive.DBS d ON t.DB_ID = d.DB_ID   "
"         ) as t  "
"         left join (  "
"            select   "
"                d.NAME as DatabaseName,    "
"                t.TBL_NAME as TableName,  "
"                tp.PARAM_VALUE as TotalSize  "
"            FROM hive.TBLS t   "
"            inner join hive.DBS d   "
"                ON t.DB_ID = d.DB_ID   "
"            left join hive.TABLE_PARAMS tp   "
"                on t.TBL_ID = tp.TBL_ID   "
"                and tp.PARAM_KEY = 'totalSize'  "
"         ) as ts  "
"            on t.TableName = ts.TableName  "
"            and t.DatabaseName = ts.DatabaseName  "
"         left join (  "
"            select   "
"                d.NAME as DatabaseName,    "
"                t.TBL_NAME as TableName,  "
"                tp.PARAM_VALUE as RowCount  "
"            FROM hive.TBLS t   "
"            inner join hive.DBS d   "
"                ON t.DB_ID = d.DB_ID   "
"            left join hive.TABLE_PARAMS tp   "
"                on t.TBL_ID = tp.TBL_ID   "
"                and tp.PARAM_KEY = 'numRows'  "
"         ) as rowcount  "
"            on t.TableName = rowcount.TableName  "
"            and t.DatabaseName = rowcount.DatabaseName "
"         left join ( select  "
"               d.NAME as DatabaseName,   "
"               t.TBL_NAME as TableName,  "
"               GROUP_CONCAT(pk.PKEY_NAME order by pk.INTEGER_IDX) as PartitionColumn "
"           from hive.TBLS t  "
"           inner join hive.DBS d  "
"               ON t.DB_ID = d.DB_ID  "
"           left join hive.PARTITION_KEYS pk  "
"               on t.TBL_ID = pk.TBL_ID  "
"           group by pk.TBL_ID  "
"        ) as part "
"           on t.TableName = part.TableName "
"           and t.DatabaseName = part.DatabaseName "
"           left join (     "
"           select "
"               base.DatabaseName, "
"               base.TableName,     "
"               GROUP_CONCAT(parts.Location) as Location "
"           from (  "
"               select  "
"                   d.NAME as DatabaseName, "
"                   t.TBL_NAME as TableName, "
"                   s.LOCATION as Location, "
"                   s.CD_ID  "
"               from hive.TBLS t  "
"               inner join hive.DBS d  "
"                   on d.DB_ID =t.DB_ID  "
"               left join hive.SDS s  "
"                       on s.SD_ID = t.SD_ID  "
"           ) as base "
"           left join ( "
"               select  "
"                   s.LOCATION as Location, "
"                   s.CD_ID  "
"               from hive.SDS s  "
"           ) as parts "
"               on base.CD_ID = parts.CD_ID "
"           group by base.DatabaseName, "
"               base.TableName "
"        ) as loc "
"           on t.TableName = loc.TableName "
"           and t.DatabaseName = loc.DatabaseName "
"         left join (  "
"            select  "
"                d.NAME as DatabaseName,  "
"                t.TBL_NAME as TableName,  "
"                SUM(pp.PARAM_VALUE) as TotalSize  "
"            from hive.TBLS t   "
"            inner join hive.DBS d   "
"                on d.DB_ID =t.DB_ID    "
"            left join hive.PARTITIONS p   "
"                on t.TBL_ID = p.TBL_ID   "
"            left join hive.PARTITION_PARAMS pp   "
"                on p.PART_ID = pp.PART_ID   "
"                and pp.PARAM_KEY = 'totalSize'  "
"            group by d.NAME, t.TBL_NAME   "
"         ) as partsize  "
"            on t.TableName = partsize.TableName  "
"            and t.DatabaseName = partsize.DatabaseName  "
"          left join (  "
"            select  "
"                d.NAME as DatabaseName,  "
"                t.TBL_NAME as TableName,  "
"                SUM(pp.PARAM_VALUE) as RowCount  "
"            from hive.TBLS t   "
"            inner join hive.DBS d   "
"                on d.DB_ID =t.DB_ID    "
"            left join hive.PARTITIONS p   "
"                on t.TBL_ID = p.TBL_ID   "
"            left join hive.PARTITION_PARAMS pp   "
"                on p.PART_ID = pp.PART_ID   "
"                and pp.PARAM_KEY = 'numRows'  "
"            group by d.NAME, t.TBL_NAME   "
"         ) as partrowcount  "
"            on t.TableName = partrowcount.TableName  "
"            and t.DatabaseName = partrowcount.DatabaseName ")

def create_widgets(connection_key):
    connection_profile = {}
    for widget in conn_params[connection_key]['params']:
        if widget['widget_type'] == "text_input":
            if 'environment' == widget['param_name']:
                st.text_input(label=widget['widget_name'], value=widget['default'], disabled=eval(widget['disabled']), key=f"{connection_key}_{widget['param_name']}")
            elif 'driver' not in widget['param_name']:
                connection_profile[widget['param_name']] = str(st.text_input(label=widget['widget_name'], value=widget['default'], disabled=eval(widget['disabled']), key=f"{connection_key}_{widget['param_name']}"))            
            else:
                if 'driver' not in connection_profile:
                    connection_profile['driver'] = {}
                connection_profile['driver'][widget['param_name'].replace('driver','')] = str(st.text_input(label=widget['widget_name'], value=widget['default'], disabled=eval(widget['disabled']), key=f"{connection_key}_{widget['param_name']}"))
        elif widget['widget_type'] == "password":
            connection_profile[widget['param_name']] = str(st.text_input(label=widget['widget_name'], value=widget['default'], disabled=eval(widget['disabled']), key=f"{connection_key}_{widget['param_name']}", type="password"))
        elif widget['widget_type'] == "selectbox":
            connection_profile[widget['param_name']] = str(st.selectbox(label=widget['widget_name'], options=widget['options'], disabled=eval(widget['disabled']), index=widget['default'], key=f"{connection_key}_{widget['param_name']}"))
        elif widget['widget_type'] == "text":
            connection_profile[widget['param_name']] = str(st.text(body=widget['widget_name']))
    return connection_profile

def user_home_directory():
    userhome = ""
    if platform.system().lower() != 'windows':
        userhome = os.getenv('HOME')
    else:
        userhome = os.getenv('USERPROFILE')
    return userhome

def check_for_empty_params(config):
    missingconfigs = []
    for key in config.keys():
        if config[key] == "" and key != 'database':
            missingconfigs.append(f"Missing config for {key}.")
    return missingconfigs

def create_profile(source, target, source_connection, target_connection, state_manager, state_manager_connection):
    # print("******************")
    # print(source, target, source_connection, target_connection, state_manager, state_manager_connection)
    # print("******************")
    profile = {}
    create_full_profile = False
    hdm_dir = os.path.join(user_home_directory(), ".hashmap_data_migrator")
    hdm_archive = os.path.join(user_home_directory(), ".hashmap_data_migrator", "Archive")
    if not os.path.isdir(hdm_dir):
        os.makedirs(hdm_dir) 
    if not os.path.isdir(hdm_archive):
        os.makedirs(hdm_archive)

    if len(source_connection) > 0 and len(target_connection) > 0 and len(state_manager_connection) > 0:  
        create_full_profile = True
        st.info(f"Creating hdm_profiles.yml at {str(hdm_dir)}")

    # profile[st.session_state[f"{source}_environment"]] = {}
    # if len(source_connection) > 0:                
    #     profile[st.session_state[f"{source}_environment"]][source.lower()] = source_connection
    # if len(target_connection) > 0:
    #     profile[st.session_state[f"{source}_environment"]][target.lower()] = target_connection
    # if len(state_manager_connection) > 0:
    #     profile[st.session_state[f"{source}_environment"]]['state_manager'] = state_manager_connection


    profile['dev'] = {}
    if len(source_connection) > 0:                
        profile['dev'][source.lower()] = source_connection

    current_timestamp = str(datetime.datetime.now()).replace(' ','').replace('-','').replace(':','').replace('.','')
    if os.path.exists(os.path.join(hdm_dir, 'hdm_profiles.yml')):
        shutil.move(os.path.join(hdm_dir, 'hdm_profiles.yml'), os.path.join(hdm_archive, f"profile_{current_timestamp}.yml"))
    
    with open(os.path.join(hdm_dir, 'hdm_profiles.yml'), 'w') as outfile:
        yaml.dump(profile, outfile, default_flow_style=False)    

def create_manifest(tableconfigs):
    manifest = {}
    current_timestamp = str(datetime.datetime.now()).replace(' ','').replace('-','').replace(':','').replace('.','')
    hdm_dir = os.path.join(user_home_directory(), ".hashmap_data_migrator")
    hdm_archive = os.path.join(user_home_directory(), ".hashmap_data_migrator", "Archive")
    if not os.path.isdir(hdm_dir):
        os.makedirs(hdm_dir) 
    if not os.path.isdir(hdm_archive):
        os.makedirs(hdm_archive)
    
    st.info(f"Creating hdm_manifest_{current_timestamp}.yml at {str(hdm_dir)}...")
    manifest['state_manager'] = {}
    manifest['state_manager']['name'] = 'state_manager'
    manifest['state_manager']['type'] = statemanager
    manifest['state_manager']['conf'] = {}
    manifest['state_manager']['conf']['connection'] = 'state_manager'

    manifest['source'] = {}
    manifest['source']['name'] = f"{source.lower()}_source"
    manifest['source']['type'] = "GCPSource"
    manifest['source']['conf'] = {}
    manifest['source']['conf']['env'] = source.lower()
    manifest['source']['conf']['directorypath'] = "C:/NTTDATA/Deutche_Bank/hdm_dev"
    manifest['source']['conf']['scenarios'] = []
    for key in tableconfigs.keys():
        for table in tableconfigs[key]:
            if table['exportornot'] == "Export":                
                tablemigrationconfig = {}
                for tableconfig in table.keys():
                    if tableconfig != 'cdcmode':
                        tablemigrationconfig[tableconfig] = table[tableconfig]
                tablemigrationconfig['project'] = key

                tablemigrationconfig['cdc'] = {}
                tablemigrationconfig['cdc']['mode'] = table['cdcmode']
                tablemigrationconfig['cdc']['keytable'] = {}
                tablemigrationconfig['cdc']['keytable']['tablename'] = ""
                tablemigrationconfig['cdc']['keytable']['tablenamecolumn'] = ""
                tablemigrationconfig['cdc']['keytable']['keycolumn'] = ""

                tablemigrationconfig['watermark'] = {}
                tablemigrationconfig['watermark']['column'] = ''
                tablemigrationconfig['watermark']['offset'] = ''

                manifest['source']['conf']['scenarios'].append(tablemigrationconfig)
    
    manifest['sink'] = {}
    manifest['sink']['name'] = f"{target.lower()}_sink"
    manifest['sink']['type'] = "SnowflakeGCSCopySink"
    manifest['sink']['conf'] = {}
    manifest['sink']['conf']['env'] = target.lower()
    manifest['sink']['conf']['source_env'] = source.lower()
    manifest['sink']['conf']['file_format'] = 'csv'
    manifest['sink']['conf']['stage_name'] = ''
    manifest['sink']['conf']['stage_directory'] = ''
    
    with open(os.path.join(hdm_dir, f"hdm_manifest_{current_timestamp}.yml"), 'w') as outfile:
        yaml.dump(manifest, outfile, default_flow_style=False)

    return str(os.path.join(hdm_dir, f"hdm_manifest_{current_timestamp}.yml")).replace("\\","/")


def test_source_connection(source, source_connection):
    try:
        success = True
        missingconfigs = check_for_empty_params(source_connection)
        if not missingconfigs:
            #print(source,  source_connection)
            create_profile(source, "", source_connection, "", "", {})
            dao: RdbmsDAO = providah_pkg_factory.create(key='Hive',
                                                        library='hdm',
                                                        configuration={
                                                            'connection': 'hive'})

            if dao is not None:
                st.info(f"{source} Connection Succeded")
            
        else:
            st.error(f"{source} - {missingconfigs}")
            success = False
    except Exception as e:
        st.error(f"Error in connnecting: {str(e)}")
        success = False
    return success

def test_target_connection(target, target_connection):        
    # try:
    #     success = True
    #     missingconfigs = check_for_empty_params(target_connection)
    #     if not missingconfigs:
    #         create_profile(source, target, "", target_connection, "", {})   
    #         with Snowflake(connection=target.lower()).connection as snowconn:
    #             st.info(f"{target} Connection Succeded")
    #     else:
    #         st.error(f"{target} - {missingconfigs}")
    #         success = False
    # except Exception as e:
    #     st.error(f"Error: {str(e)}")
    #     success = False
    #return success
    return True

def test_state_manager_connection(target, target_connection):        
    # try:
    #     success = True
    #     missingconfigs = check_for_empty_params(target_connection)
    #     if not missingconfigs:
    #         create_profile(source, "", "", "", target, target_connection)   
    #         with Snowflake(connection=target.lower()).connection as snowconn:
    #             st.info(f"{target} Connection Succeded")
    #     else:
    #         st.error(f"{target} - {missingconfigs}")
    #         success = False
    # except Exception as e:
    #     st.error(f"Error: {str(e)}")
    #     success = False
    # return success
    return True

def fetch_all(query_string) -> pd.DataFrame:
    print(query_string)
    df_result_set = None
    try:
        dao: RdbmsDAO = providah_pkg_factory.create(key='Hive',
                                            library='hdm',
                                            configuration={
                                                'connection': 'hive'})

        with dao.get_connection() as conn:                
            if conn is not None:
                cursor = conn.cursor()
                print(query_string)
                cursor.execute(query_string)
                columns = cursor.description
                result_set = [{columns[row_index][0]: value for row_index, value in enumerate(record)} for record in
                            cursor.fetchall()]
                df_result_set = pd.DataFrame(result_set)
    except:
        raise

    return df_result_set

def fetchdata(source, source_connection):
    st.session_state["TableData"] = []
    df_result_set = pd.DataFrame()
    # print("***************")
    # print(__template_select_table_summary.substitute(a=''))
    # print('********************')
          
    df_result_set = fetch_all(__template_select_table_summary.substitute(a=''))
    #st.dataframe(df_result_set)
    st.session_state['TableData'].append(df_result_set)

    #         st.session_state['TableData'].append(df_result_set_temp)
    # if st.session_state[f"{source}_service_json"] != "":
    #     with open(st.session_state[f"{source}_service_json"], "r") as fileobj:
    #         bq_database = json.load(fileobj)['project_id']

    #     if bq_database == None:
    #         bq_database = ""

    #     with GCP(connection=source.lower()).connection as conn:
    #         datasetslist = conn.list_datasets()

    #     for dataset in datasetslist:
    #         df_result_set_temp = fetch_all(template_select_summary.substitute(db=bq_database, dataset=dataset.dataset_id), source)
    #         st.session_state['TableData'].append(df_result_set_temp)
       
def toggleexportornot(database):
    if 'changebasedonsession' in st.session_state:
        if database in st.session_state['changebasedonsession']:
            for chk in st.session_state['changebasedonsession'][database]:
                if st.session_state[f"{database}_SelectAll"]:
                    st.session_state[chk] = "Export"
                else:
                    st.session_state[chk] = "Do Not Export"
                print(chk, st.session_state[chk])

def create_migration_widgets():
    tableconfigs = OrderedDict()
    prevdatabaseunique = ""
    tableconfig = OrderedDict()
    if 'TableData' in st.session_state:
        if len(st.session_state['TableData']) > 0:
            for database in st.session_state['TableData']:
                if database.shape[0] > 0:
                    databaseunique = database.DatabaseName.unique()[0]
                    if databaseunique not in tableconfigs:
                        tableconfigs[databaseunique] = []
                        if len(tableconfig.keys()) > 0:
                            tableconfigs[prevdatabaseunique].append(tableconfig)
                            tableconfig = OrderedDict()
                    with st.expander(databaseunique, expanded=True):
                        st.checkbox(label="Export All", on_change=toggleexportornot, kwargs={"database": databaseunique}, key=f"{databaseunique}_SelectAll", value=False)
                        cols = st.columns(spec=len(conn_params[source]['migrationconfig']), gap="small")
                        migrationconfigcounter = 0
                        migrationconfiglist = []
                        for i, x in enumerate(cols):
                            migrationconfiglist.append(x)

                        for migrationconfig in migrationconfiglist:
                            with migrationconfig:
                                st.markdown(f"**{conn_params[source]['migrationconfig'][migrationconfigcounter]['widget_name']}**")
                                migrationconfigcounter = migrationconfigcounter + 1
                        
                        
                        for index, row in database.iterrows():
                            migrationconfigcounter = 0
                            if f"{databaseunique}_ExportOrNot" not in st.session_state:
                                st.session_state[f"{databaseunique}_ExportOrNot"] = []
                            if len(tableconfig.keys()) > 0:
                                tableconfigs[databaseunique].append(tableconfig)
                                tableconfig = OrderedDict()
                            # if prevdatabaseunique != databaseunique:
                            #     tableconfigs[prevdatabaseunique].append(tableconfig)
                            #     tableconfig = {}

                            for migrationconfig in migrationconfiglist:
                                with migrationconfig:
                                    config = conn_params[source]['migrationconfig'][migrationconfigcounter]
                                    if config['widget_type'] == "selectbox":
                                        st.selectbox(label=config['widget_name'],
                                                    label_visibility="collapsed",
                                                    options=config['options'],
                                                    key=f"{row['DatabaseName']}.{row['TableName']}_{config['param_name']}", 
                                                    index=config['default'], 
                                                    disabled=eval(config['disabled']))

                                    elif config['widget_type'] == "text_input":
                                        derivedvalue = ""
                                        if 'default' in config:
                                            if '<' in config['default']:
                                                dbkeys = config['default'].replace('<','').replace('>','').split('_')                                        
                                                for dbkey in dbkeys:
                                                    derivedvalue = f"{derivedvalue}.{row[dbkey]}"
                                                derivedvalue = derivedvalue[1:]

                                        st.text_input(label=config['widget_name'],
                                                    key=f"{row['DatabaseName']}.{row['TableName']}_{config['param_name']}", 
                                                    disabled=eval(config['disabled']),
                                                    label_visibility="collapsed",
                                                    placeholder=config['placeholder'],
                                                    value=derivedvalue if derivedvalue != "" else config['default'])
                                    
                                    if eval(config.get('storeinsession',"False")):
                                        if 'changebasedonsession' not in st.session_state:
                                            st.session_state['changebasedonsession'] = {}
                                        if databaseunique not in st.session_state['changebasedonsession']:
                                            st.session_state['changebasedonsession'][databaseunique] = []
                                        if f"{row['DatabaseName']}.{row['TableName']}_{config['param_name']}" not in st.session_state['changebasedonsession'][databaseunique]:
                                            st.session_state['changebasedonsession'][databaseunique].append(f"{row['DatabaseName']}.{row['TableName']}_{config['param_name']}")
                                    
                                    if not eval(config.get('informational',"False")):
                                        tableconfig[config['param_name']] = st.session_state[f"{row['DatabaseName']}.{row['TableName']}_{config['param_name']}"]
                                    # prevdatabaseunique = databaseunique

                                    migrationconfigcounter = migrationconfigcounter + 1
                            if len(tableconfigs[databaseunique]) == database.shape[0]-1:
                                if len(tableconfig.keys()) > 0:
                                    tableconfigs[databaseunique].append(tableconfig)
                                    tableconfig = OrderedDict()

    return tableconfigs

def plotlygrid(data, title):
    fig = go.Figure(data=[
                            go.Table(
                                    columnorder = [1,2,3,4],
                                    columnwidth = [60,60,40,400],
                                    header = dict(
                                                    values = [f"<b>{x}</b>" for x in list(data.columns)],
                                                    line_color='darkslategray',
                                                    fill_color='royalblue',
                                                    align=['left'],
                                                    font=dict(color='white', size=16),
                                                    height=40
                                                 ),
                                    cells=dict(
                                                values=[data.Timestamp, data.Name, data.Level, data.Message],
                                                line_color='darkslategray',
                                                fill=dict(color=['paleturquoise', 'white']),
                                                align=['left'],
                                                font_size=14,
                                                height=30
                                              )
                                    )
                            ], 
                            layout=go.Layout(
                                                title=go.layout.Title(text=f"<b>{title}</b>"), 
                                                height=1000
                                            )
                    )
    st.plotly_chart(fig, theme=None, use_container_width=False)

def migrate(manifest_file, logs):
    try:
        exportprocess = subprocess.Popen(["python", os.path.join(os.path.split(os.path.split(os.path.abspath(__file__))[0])[0], "hdm", "hashmap_data_migrator.py"), "--manifest", manifest_file, "--env", "dev", "--data_staging", "C:/NTTDATA/Accelerators", "--log_settings", "C:/NTTDATA/Deutche_Bank/hashmap_data_migrator_hive_bigquery/hdm/core/logs/log_settings.yml"], shell=False, stdout=subprocess.PIPE)
        importprocess = subprocess.Popen(["python", os.path.join(os.path.split(os.path.split(os.path.abspath(__file__))[0])[0], "hdm", "hashmap_snowflake_importer.py"), "--manifest", manifest_file, "--env", "dev", "--data_staging", "C:/NTTDATA/Accelerators", "--log_settings", "C:/NTTDATA/Deutche_Bank/hashmap_data_migrator_hive_bigquery/hdm/core/logs/log_settings.yml"], shell=False, stdout=subprocess.PIPE)
        # Poll process.stdout to show stdout live
        with logs:
            placeholder = st.empty()
            placeholder1 = st.empty()
            exportpoll = True
            importpoll = True
            
            while True:
                if exportpoll:
                    output = exportprocess.stdout.readline()                            
                    if output: 
                        outputdata = output.strip().decode('utf-8').split(' - ')                            
                        st.session_state['exportdf'] = pd.concat([st.session_state['exportdf'], pd.DataFrame([{'Timestamp': outputdata[0], 'Name': outputdata[1], 'Level': outputdata[2], 'Message': outputdata[3]}])])                                

                        with placeholder.container():
                            plotlygrid(st.session_state['exportdf'], "Export Logs")
                    if exportprocess.poll() is not None:
                        exportpoll = False
                if importpoll:
                    output1 = importprocess.stdout.readline()
                    if output1:
                        outputdata1 = output1.strip().decode('utf-8').split(' - ')                            
                        st.session_state['importdf'] = pd.concat([st.session_state['importdf'], pd.DataFrame([{'Timestamp': outputdata1[0], 'Name': outputdata1[1], 'Level': outputdata1[2], 'Message': outputdata1[3]}])])

                        with placeholder1.container():
                            plotlygrid(st.session_state['importdf'], "Import Logs")
                    if importprocess.poll() is not None:
                        importpoll = False

                if not exportpoll and not importpoll:
                    break
                
            if exportpoll:
                rc = exportprocess.poll()
            if importpoll:
                rc1 = importprocess.poll()
    except Exception as e:
        st.error(str(e))
        
st.set_page_config(layout="wide", page_title="NTT Data Migrator")
conn_params = json.load(open(os.path.join(os.path.split(os.path.abspath(__file__))[0], "widgets.json")))
st.title("NTT Data Migrator")
source = "Hive"
target = "BigQuery"
statemanager = "BigQueryStateManager"

connections, inventory, logs = st.tabs(["🔗 Connections", "📃Inventory", "🗃 Logs"])

with connections:          
    with st.expander("Source", expanded=True):
        source_connection = create_widgets(source)
        if st.button("Test Connection", key="TestSourceConnection"):
            test_source_connection(source, source_connection)
    with st.expander("Target", expanded=False):
        target_connection = create_widgets(target)
        if st.button("Test Connection", key="TestTargetConnection"):
            test_target_connection(target, target_connection)
    with st.expander("State Manager", expanded=False):
        state_manager_connection = create_widgets(statemanager)
        if st.button("Test Connection", key="TestStateManagerConnection"):
            test_state_manager_connection('state_manager', state_manager_connection)

    st.button("Fetch Inventory", key="FetchInventory")

    if st.session_state.FetchInventory:
        with st.spinner("Fetching Inventory"):
            if test_source_connection(source, source_connection):
                create_profile(source, "", source_connection, {}, "", {})
                # st.info("Fetching Inventory...")
                st.session_state['TableData'] = []
                fetchdata(source,source_connection)
                st.info("Inventory fetched. Please refer to Inventory tab...")
    
if 'TableData' in st.session_state and len(st.session_state['TableData']) > 0:
    with inventory:
        tableconfigs = create_migration_widgets()                
        st.button("Migrate", key="MigrateData")
        if st.session_state.MigrateData:
            with st.spinner("Migrating Data"):
                #if test_source_connection(source, source_connection) and test_target_connection(target, target_connection) and test_state_manager_connection('state_manager', state_manager_connection):
                create_profile(source, target, source_connection, 'BigQuery', statemanager, state_manager_connection)
                st.session_state['exportdf'] = pd.DataFrame(columns=['Timestamp', 'Name', 'Level', 'Message'])
                st.session_state['importdf'] = pd.DataFrame(columns=['Timestamp', 'Name', 'Level', 'Message'])
                manifest_file = create_manifest(tableconfigs)             
                st.info("Initiating migration")
                migrate(manifest_file, logs)                
                st.info("Data migrated")
